-- phpMyAdmin SQL Dump
-- version 4.4.12
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 02-12-2015 a las 06:37:24
-- Versión del servidor: 5.6.25
-- Versión de PHP: 5.6.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `INVEN`
--
CREATE DATABASE IF NOT EXISTS `INVEN` DEFAULT CHARACTER SET latin1 COLLATE latin1_swedish_ci;
USE `INVEN`;

DELIMITER $$
--
-- Procedimientos
--
DROP PROCEDURE IF EXISTS `PA_ActualizaCliente`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_ActualizaCliente`(IN `Cliente` BIGINT, IN `Nombres` VARCHAR(200), IN `Apellidos` VARCHAR(200), IN `Ciudad` VARCHAR(200), IN `Telefono` VARCHAR(200), IN `RFC` VARCHAR(200), IN `FechaNacimiento` DATE, IN `Estado` VARCHAR(200), IN `Municipio` VARCHAR(200), IN `CodigoPostal` VARCHAR(200), IN `LugarNacimiento` VARCHAR(1000), IN `Direccion` VARCHAR(1000))
    MODIFIES SQL DATA
UPDATE `Clientes` SET 
`Nombres`=Nombres
,`Apellidos`=Apellidos
,`Direccion`=Direccion
,`Ciudad`=Ciudad
,`Telefono`=Telefono
,`RFC`=RFC
,`FechaNacimiento`=FechaNacimiento
,`Estado`=Estado
,`Municipio`=Municipio
,`CodigoPostal`=CodigoPostal
,`LugarNacimiento`=LugarNacimiento

WHERE idCliente=Cliente$$

DROP PROCEDURE IF EXISTS `PA_ActualizarGrupo`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_ActualizarGrupo`(IN `parIDGrupo` BIGINT, IN `parDescripcion` VARCHAR(200), IN `parAccesoConfiguracion` BOOLEAN, IN `parAccesoGrupos` BOOLEAN, IN `parAccesoUsuarios` BOOLEAN, IN `parAccesoClientes` BOOLEAN, IN `parAccesoArticulos` BOOLEAN, IN `parAccesoInventario` BOOLEAN)
    NO SQL
update GruposUsuarios 

set Descripcion=parDescripcion
	,accesoConfiguracion=parAccesoConfiguracion
    ,accesoGrupos=parAccesoGrupos
    ,accesoUsuarios=parAccesoUsuarios
    ,accesoClientes=parAccesoClientes
    ,accesoArticulos=parAccesoArticulos
    ,accesoInventario=parAccesoInventario

where idGrupoUsuario=parIDGrupo$$

DROP PROCEDURE IF EXISTS `PA_ActualizarUsuario`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_ActualizarUsuario`(IN `parUsuario` VARCHAR(100), IN `parContra` VARCHAR(200), IN `parGrupo` MEDIUMINT, IN `parNombre` CHAR(200))
    NO SQL
update Usuarios set 
Usuario=parUsuario
,Contra=parContra
,Grupo=parGrupo
,Nombre=parNombre
where Usuario=parUsuario$$

DROP PROCEDURE IF EXISTS `PA_CuantosClientes`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_CuantosClientes`(IN `Busqueda` VARCHAR(200))
    READS SQL DATA
    DETERMINISTIC
BEGIN

SELECT COUNT(*) as cuantos
FROM `INVEN`.`Clientes`
where Nombres LIKE CONCAT('%',Busqueda,'%')
	  or	Nombres LIKE CONCAT('%',Busqueda,'%')
      or	Apellidos LIKE CONCAT('%',Busqueda,'%')
      or	Direccion LIKE CONCAT('%',Busqueda,'%')
      or	Ciudad LIKE CONCAT('%',Busqueda,'%')
      or	Telefono LIKE CONCAT('%',Busqueda,'%')
      or	RFC LIKE CONCAT('%',Busqueda,'%')
      or	Estado LIKE CONCAT('%',Busqueda,'%');

END$$

DROP PROCEDURE IF EXISTS `PA_CuantosGrupos`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_CuantosGrupos`(IN `parBusqueda` VARCHAR(200))
    NO SQL
SELECT COUNT(*) as cuantos
FROM `INVEN`.`GruposUsuarios`
where Descripcion LIKE CONCAT('%',parBusqueda,'%')$$

DROP PROCEDURE IF EXISTS `PA_CuantosUsuarios`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_CuantosUsuarios`(IN `parBusqueda` VARCHAR(200))
    NO SQL
SELECT COUNT(*) as cuantos
FROM Usuarios
where Nombre LIKE CONCAT('%',parBusqueda,'%')
or Usuario LIKE CONCAT('%',parBusqueda,'%')$$

DROP PROCEDURE IF EXISTS `PA_EliminarCliente`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_EliminarCliente`(IN `idCliente1` BIGINT)
    NO SQL
delete 
FROM Clientes 
WHERE idCliente=idCliente1$$

DROP PROCEDURE IF EXISTS `PA_EliminarGrupo`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_EliminarGrupo`(IN `parIDGrupo` INT)
    NO SQL
delete from GruposUsuarios where idGrupoUsuario = parIDGrupo$$

DROP PROCEDURE IF EXISTS `PA_EliminarUsuario`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_EliminarUsuario`(IN `parUsuario` VARCHAR(200))
    NO SQL
delete from Usuarios where usuario=parUsuario$$

DROP PROCEDURE IF EXISTS `PA_InsertaGrupoUsuario`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_InsertaGrupoUsuario`(IN `ParDescripcion` VARCHAR(200), IN `parAccesoConfiguracion` BOOLEAN, IN `parAccesoGrupos` BOOLEAN, IN `parAccesoUsuarios` BOOLEAN, IN `parAccesoClientes` BOOLEAN, IN `parAccesoArticulos` BOOLEAN, IN `parAccesoInventario` BOOLEAN)
    NO SQL
insert into GruposUsuarios (Descripcion
                            ,accesoConfiguracion
                           	,accesoGrupos
                            ,accesoUsuarios
                            ,accesoClientes
                            ,accesoArticulos
                            ,accesoInventario
                           )
values(ParDescripcion
      ,parAccesoConfiguracion
      ,parAccesoGrupos
      ,parAccesoUsuarios 
      ,parAccesoClientes
      ,parAccesoArticulos
      ,parAccesoInventario 
      )$$

DROP PROCEDURE IF EXISTS `PA_InsertaUsuario`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_InsertaUsuario`(IN `parUsuario` VARCHAR(100), IN `parContra` VARCHAR(200), IN `parGrupo` MEDIUMINT, IN `parNombre` VARCHAR(200))
    NO SQL
insert into Usuarios (Usuario,Contra,Grupo,Nombre)
values(parUsuario,parContra,parGrupo,ParNombre)$$

DROP PROCEDURE IF EXISTS `PA_LeeCliente`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_LeeCliente`(IN `cliente` BIGINT)
SELECT right(`Clientes`.`idCliente`,5) as idCliente,
    `Clientes`.`Nombres`,
    `Clientes`.`Apellidos`,
    `Clientes`.`Direccion`,
    `Clientes`.`Ciudad`,
    `Clientes`.`Telefono`,
    `Clientes`.`RFC`,
    `Clientes`.`FechaNacimiento`,
    `Clientes`.`Estado`,
    `Clientes`.`Municipio`,
    `Clientes`.`CodigoPostal`,
    `Clientes`.`LugarNacimiento`
FROM `INVEN`.`Clientes`
WHERE idCliente=cliente$$

DROP PROCEDURE IF EXISTS `PA_LeeClientes`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_LeeClientes`(IN `desde` BIGINT, IN `cuantos` BIGINT, IN `Busqueda` VARCHAR(200))
    READS SQL DATA
BEGIN

SELECT right(`Clientes`.`idCliente`,5) as idCliente,
    `Clientes`.`Nombres`,
    `Clientes`.`Apellidos`,
    `Clientes`.`Direccion`,
    `Clientes`.`Ciudad`,
    `Clientes`.`Telefono`,
    `Clientes`.`RFC`,
    `Clientes`.`FechaNacimiento`,
    `Clientes`.`Estado`,
    `Clientes`.`Municipio`,
    `Clientes`.`CodigoPostal`
FROM `INVEN`.`Clientes`
where Nombres LIKE CONCAT('%',Busqueda,'%')
	  or	Nombres LIKE CONCAT('%',Busqueda,'%')
      or	Apellidos LIKE CONCAT('%',Busqueda,'%')
      or	Direccion LIKE CONCAT('%',Busqueda,'%')
      or	Ciudad LIKE CONCAT('%',Busqueda,'%')
      or	Telefono LIKE CONCAT('%',Busqueda,'%')
      or	RFC LIKE CONCAT('%',Busqueda,'%')
      or	Estado LIKE CONCAT('%',Busqueda,'%')
limit desde,cuantos;


END$$

DROP PROCEDURE IF EXISTS `PA_LeeGruposUsuarios`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_LeeGruposUsuarios`(IN `parDesde` BIGINT, IN `parCuantos` BIGINT, IN `parBusqueda` VARCHAR(200))
    NO SQL
SELECT right(`GruposUsuarios`.`idGrupoUsuario`,5) as idGrupoUsuario,
    `GruposUsuarios`.`Descripcion`
   
FROM `INVEN`.`GruposUsuarios`
where Descripcion LIKE CONCAT('%',parBusqueda,'%')

limit parDesde,parCuantos$$

DROP PROCEDURE IF EXISTS `PA_LeerGrupoUsuario`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_LeerGrupoUsuario`(IN `parIDGrupoUsuario` BIGINT)
    NO SQL
SELECT idGrupoUsuario
,Descripcion 
,accesoConfiguracion
,accesoGrupos
,accesoUsuarios
,accesoClientes
,accesoArticulos
,accesoInventario
from GruposUsuarios where idGrupoUsuario=parIDGrupoUsuario$$

DROP PROCEDURE IF EXISTS `PA_LeeUsuario`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_LeeUsuario`(IN `parUsuario` VARCHAR(200))
    NO SQL
SELECT right(a.idUsuario,5) as idUsuario
		,a.Usuario
        ,a.Contra
        ,(SELECT b.Descripcion from GruposUsuarios b where b.IdGrupoUsuario=a.Grupo) as grupo 
        ,a.Nombre
        ,right(a.Grupo,4) as idGrupo
    
FROM Usuarios a
where a.Usuario =parUsuario$$

DROP PROCEDURE IF EXISTS `PA_LeeUsuarios`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `PA_LeeUsuarios`(IN `parDesde` BIGINT, IN `parCuantos` BIGINT, IN `parBusqueda` VARCHAR(200))
    NO SQL
SELECT idUsuario,USUARIO,CONTRA ,(SELECT b.Descripcion from GruposUsuarios b where b.IdGrupoUsuario=a.Grupo) as grupo 
,a.Nombre
,a.idUsuario
,a.Grupo as idGrupo
from Usuarios a
where a.Usuario LIKE CONCAT('%',parBusqueda,'%')


limit parDesde,parCuantos$$

DROP PROCEDURE IF EXISTS `sp_InsertaCliente`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `sp_InsertaCliente`(IN `Nombres` VARCHAR(200), IN `Apellidos` VARCHAR(200), IN `Direccion` VARCHAR(200), IN `Ciudad` VARCHAR(200), IN `Telefono` VARCHAR(200), IN `RFC` VARCHAR(10), IN `FechaNacimiento` VARCHAR(200), IN `Estado` VARCHAR(200), IN `Municipio` VARCHAR(200), IN `CodigoPostal` VARCHAR(200), IN `LugarNacimiento` VARCHAR(1000))
BEGIN
 
    INSERT INTO `Clientes`
    (
    `Nombres`,
    `Apellidos`,
    `Direccion`,
    `Ciudad`,
    `Telefono`,
    `RFC`,
    `FechaNacimiento`,
    `Estado`,
    `Municipio`,
    `CodigoPostal`,
    `LugarNacimiento`
        )
    VALUES
    (
    Nombres,
    Apellidos,
    Direccion,
    ciudad,
    Telefono,
    RFC,
    FechaNacimiento,
    Estado,
    Municipio,
    CodigoPostal,
    LugarNacimiento
    );
 
END$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Clientes`
--

DROP TABLE IF EXISTS `Clientes`;
CREATE TABLE IF NOT EXISTS `Clientes` (
  `idCliente` bigint(20) unsigned zerofill NOT NULL,
  `Nombres` varchar(100) DEFAULT NULL,
  `Apellidos` varchar(45) DEFAULT NULL,
  `Direccion` varchar(45) DEFAULT NULL,
  `Ciudad` varchar(45) DEFAULT NULL,
  `Telefono` varchar(45) DEFAULT NULL,
  `RFC` varchar(45) DEFAULT NULL,
  `FechaNacimiento` date DEFAULT NULL,
  `Estado` varchar(45) DEFAULT NULL,
  `Municipio` varchar(45) DEFAULT NULL,
  `CodigoPostal` varchar(45) DEFAULT NULL,
  `LugarNacimiento` varchar(2000) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Clientes`
--

INSERT INTO `Clientes` (`idCliente`, `Nombres`, `Apellidos`, `Direccion`, `Ciudad`, `Telefono`, `RFC`, `FechaNacimiento`, `Estado`, `Municipio`, `CodigoPostal`, `LugarNacimiento`) VALUES
(00000000000000000008, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000017, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', '', '', '', ''),
(00000000000000000020, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000022, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000023, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000024, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000025, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000026, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000027, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000028, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000029, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', 's', '0'),
(00000000000000000030, 'cesar', 'julio', 'as', 's', 's', 'asd', '2015-01-01', 's', 's', '0', 'Los Mochis'),
(00000000000000000034, 'Mariela', 'Salomon', 'Domicilio', 'jjr', '0000000', 'RFC', '1990-07-27', '', '', '', '');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `GruposUsuarios`
--

DROP TABLE IF EXISTS `GruposUsuarios`;
CREATE TABLE IF NOT EXISTS `GruposUsuarios` (
  `IdGrupoUsuario` bigint(20) unsigned NOT NULL,
  `Descripcion` varchar(200) NOT NULL,
  `accesoUsuarios` tinyint(1) DEFAULT '0',
  `accesoGrupos` tinyint(1) DEFAULT '0',
  `accesoClientes` tinyint(1) DEFAULT '0',
  `accesoArticulos` tinyint(1) DEFAULT '0',
  `accesoConfiguracion` tinyint(1) DEFAULT '0',
  `accesoInventario` tinyint(1) DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `GruposUsuarios`
--

INSERT INTO `GruposUsuarios` (`IdGrupoUsuario`, `Descripcion`, `accesoUsuarios`, `accesoGrupos`, `accesoClientes`, `accesoArticulos`, `accesoConfiguracion`, `accesoInventario`) VALUES
(2, 'PRUEBAS', 1, 1, 1, 1, 1, 1),
(9, 'Administrador', 0, 0, 0, 0, 0, 0),
(10, 'Supervisor', 1, 1, 1, 1, 1, 1),
(11, 'Desarrollador', 1, 0, 0, 0, 0, 1),
(12, 'Inventario', 1, 0, 0, 0, 0, 1),
(21, 's', 1, 1, 1, 1, 1, 1),
(22, '1', 0, 0, 0, 0, 1, 0),
(23, '2', 0, 1, 0, 0, 0, 0),
(24, '3', 1, 0, 0, 0, 0, 0),
(25, '4', 0, 0, 1, 0, 0, 0),
(26, '5', 0, 0, 0, 1, 0, 0),
(27, '6', 0, 0, 0, 0, 0, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `Usuarios`
--

DROP TABLE IF EXISTS `Usuarios`;
CREATE TABLE IF NOT EXISTS `Usuarios` (
  `idUsuario` bigint(20) unsigned NOT NULL,
  `Usuario` varchar(300) NOT NULL,
  `Contra` varchar(300) NOT NULL,
  `Grupo` mediumint(9) NOT NULL,
  `Nombre` varchar(200) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `Usuarios`
--

INSERT INTO `Usuarios` (`idUsuario`, `Usuario`, `Contra`, `Grupo`, `Nombre`) VALUES
(1, 'Julio', 'Cesar', 2, 'adas'),
(3, 'asad', '123', 10, 'asad'),
(4, '123', '123', 13, '123'),
(5, '1231', '123', 2, '1231'),
(9, '123123', '12312', 12, '123123'),
(10, '12312', '123', 12, '12312'),
(11, 'asd', 'asd', 12, 'asd'),
(12, '', '', 2, '');

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `Clientes`
--
ALTER TABLE `Clientes`
  ADD UNIQUE KEY `idCliente` (`idCliente`);

--
-- Indices de la tabla `GruposUsuarios`
--
ALTER TABLE `GruposUsuarios`
  ADD PRIMARY KEY (`IdGrupoUsuario`);

--
-- Indices de la tabla `Usuarios`
--
ALTER TABLE `Usuarios`
  ADD PRIMARY KEY (`idUsuario`),
  ADD UNIQUE KEY `Usuario` (`Usuario`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `Clientes`
--
ALTER TABLE `Clientes`
  MODIFY `idCliente` bigint(20) unsigned zerofill NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT de la tabla `GruposUsuarios`
--
ALTER TABLE `GruposUsuarios`
  MODIFY `IdGrupoUsuario` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT de la tabla `Usuarios`
--
ALTER TABLE `Usuarios`
  MODIFY `idUsuario` bigint(20) unsigned NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=13;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
